const compression = require('compression');
const express = require('express');
const path = require('path');
const favicon = require('express-favicon');
const sql = require('mssql');
const cors = require('cors'); 

const PORT = process.env.PORT || 5000;
const app = express();

// Database configuration
const config = {
    server: 'DESKTOP-3VVDG7Q\\SQLEXPRESS',
    user: 'Newlogin',
    password: '12345',
    database: 'family_recipes_db',
    options: {
        trustedConnection: true,
        encrypt: true,
        trustServerCertificate: true
    }
};

// Connect to the database
sql.connect(config)
    .then(() => {
        console.log('Connected to SQL Server');
    })
    .catch((err) => {
        console.error('Error connecting to SQL Server:', err);
    });

//Middleware
app.use(favicon(__dirname + '/build/favicon.png'));
app.use(compression());
app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, 'build')));
app.use(express.json());


// Enable CORS for specific origin
app.use(cors({ origin: 'http://localhost:3000' }));

// API routes
app.post('/api/recipes', async (req, res) => {
  const { imageUrl, name, price, info, user, type } = req.body;

  console.log('Received request to add recipe:', { imageUrl, name, price, info, user, type });
  try {
      const request = new sql.Request();

      request.input('imageUrl', sql.VarChar(400), imageUrl);
      request.input('name', sql.VarChar(255), name);
      request.input('price', sql.Decimal(10, 2), price);
      request.input('info', sql.Text, info);
      request.input('user', sql.VarChar(255), user);
      request.input('type', sql.VarChar(255), type);

      await request.execute('AddRecipe');
      res.status(200).send('Recipe added successfully');
  } catch (err) {
      console.error('Error adding recipe:', err);
      res.status(500).send('Failed to add recipe');
  }
});



app.put('/api/recipes/:id', async (req, res) => {
  const { id } = req.params;
  const { imageUrl, name, price, info, user } = req.body; // Add user to the destructuring

  console.log('Received request to update recipe:', { id, imageUrl, name, price, info, user });

  try {
      const request = new sql.Request();

      request.input('id', sql.Int, id);
      request.input('imageUrl', sql.VarChar(255), imageUrl);
      request.input('name', sql.VarChar(255), name);
      request.input('price', sql.Decimal(10, 2), price);
      request.input('info', sql.Text, info);
      request.input('user', sql.VarChar(255), user); // Add user input parameter

      await request.execute('UpdateRecipe');
      res.status(200).send('Recipe updated successfully');
  } catch (err) {
      console.error('Error updating recipe:', err);
      res.status(500).send('Failed to update recipe');
  }
});


app.delete('/api/recipes/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const request = new sql.Request();

        request.input('id', sql.Int, id);

        await request.execute('RemoveRecipe');
        res.status(200).send('Recipe deleted successfully');
    } catch (err) {
        console.error('Error deleting recipe:', err);
        res.status(500).send('Failed to delete recipe');
    }
});


app.get('/api/recipes', async (req, res) => {
  try {
      const request = new sql.Request();

      const result = await request.query('SELECT * FROM Recipes'); // Assuming 'Recipes' is the table name
      const recipes = result.recordset;

      res.status(200).json(recipes); // Send the recipes as JSON response
  } catch (err) {
      console.error('Error fetching recipes:', err);
      res.status(500).send('Failed to fetch recipes');
  }
});


// Start the server
app.listen(PORT, function () {
    console.log(`Server running on http://localhost:${PORT}`);
});
