import { $host } from './index';

export const getAll = async (page, limit) => {
    console.log('Fetching all recipes...');
    const { data } = await $host.get('api/recipes', {
        params: {
            page,
            limit,
            sort: 'up'
        },
    });
    console.log('Fetched all recipes:', data);
    return data;
};

export const create = async (recipe) => {
    console.log('Creating recipe:', recipe);
   // let recip = (recipe.imageUrl, recipe.name, recipe.price, recipe.info)
    const { data } = await $host.post('api/recipes', recipe);
    console.log('Recipe created:', data);
    return data;
};

export const update = async (recipe) => {
    console.log('Updating recipe:', recipe);
    const { data } = await $host.put('api/recipes/' + recipe.id, recipe);
    console.log('Recipe updated:', data);
    return data;
};

export const remove = async (recipe) => {
    console.log('Removing recipe:', recipe);
    const { data } = await $host.delete('api/recipes/' + recipe.id);
    console.log('Recipe removed:', data);
    return data;
};
