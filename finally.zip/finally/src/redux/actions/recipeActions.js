import {
    ADD_RECIPE,
    CHANGE_PAGE,
    CHANGE_TOTAL,
    FETCHED_RECIPES,
    ID_ITEM_DELETE,
    INIT_RECIPES,
    REMOVE_RECIPES,
    STATE_MODAL_CREATE,
    STATE_MODAL_DELETE,
    UPDATE_RECIPES,
} from '../constants/recipeConstants';
import { create, getAll, remove, update } from '../../http/recipesAPI';

export const fetchRecipes = (page, limit) => async (dispatch) => {
    dispatch({ type: FETCHED_RECIPES });

    try {
        const res = await getAll(page, limit);
        console.log('Data from getAll:', res);
        console.log('Fetch recipes rows:', res.count);

        dispatch({
            type: INIT_RECIPES,
            payload: res,
        });
        dispatch({
            type: CHANGE_TOTAL,
            payload: res.count,
        });
        dispatch({
            type: CHANGE_PAGE,
        });
    } catch (error) {
        console.error('Error fetching recipes:', error);
        // Dispatch an action to update state with the error message or handle it as needed
    }
};

export const addRecipe = (data) => async (dispatch) => {
    try {
        const res = await create(data);
        console.log('Data to be posted:', res);
        dispatch({
            type: ADD_RECIPE,
            payload: res,
        });
    } catch (error) {
        console.error('Error adding recipe:', error);
        // Dispatch an action to update state with the error message or handle it as needed
    }
};

export const updateRecipe = (data) => async (dispatch) => {
    try {
        await update(data);

        dispatch({
            type: UPDATE_RECIPES,
            payload: data,
        });
    } catch (error) {
        console.error('Error updating recipe:', error);
        // Dispatch an action to update state with the error message or handle it as needed
    }
};

export const removeRecipe = (data) => async (dispatch) => {
    try {
        await remove({ id: data });

        dispatch({
            type: REMOVE_RECIPES,
            payload: { id: data },
        });
    } catch (error) {
        console.error('Error removing recipe:', error);
        // Dispatch an action to update state with the error message or handle it as needed
    }
};

export const showModalCreate = (data) => {
    return {
        type: STATE_MODAL_CREATE,
        payload: data,
    };
};

export const showModalDelete = (data) => {
    return {
        type: STATE_MODAL_DELETE,
        payload: data,
    };
};

export const setIdItemDelete = (data) => {
    return {
        type: ID_ITEM_DELETE,
        payload: data,
    };
};
