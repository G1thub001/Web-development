import { applyMiddleware, combineReducers, createStore } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
import {thunk} from 'redux-thunk';

import recipesReducer from '../reducers/recipesReducer';
import themeReducer from '../reducers/themeReducer';

// Combine your reducers
const rootReducer = combineReducers({
    recipes: recipesReducer,
    theme: themeReducer,
});

// Use composeWithDevTools to include the Redux DevTools extension
const store = createStore(
    rootReducer,
    {},
    composeWithDevTools(applyMiddleware(thunk))
);

export default store;
